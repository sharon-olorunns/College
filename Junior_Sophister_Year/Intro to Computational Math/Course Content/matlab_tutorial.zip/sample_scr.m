% Following lines are for debugging purposes. Usually it is not a good idea
% to use in production codes.
clear all;
close all;

% For loops
x = 1:10; % assign values from 1 to 10 to the variable x
for i=1:length(x) % for each element of x
    y(i) = x(i)^2; % square it and assign to corresponding place of y 
end % end of for loop
disp(y) % show y

% Note that, below is faster, more readable and should be preferred over the
% for loop version
y = x.^2;

% We can also nest for loops. An example is when we want to multiply a vector by
% a matrix
A = rand(3,3);
x = ones(3,1);

% Rather than nested loops we SHOULD use the native notation, but for the sake 
% of an example we are going to do it anyways.
b = A*x;

b_t = zeros(3,1); % Initialize the result vector
for j = 1:size(A,2) % Sweep over colums
    for i = 1:size(A,1) % Sweep over rows
        b_t(i) = b_t(i) + A(i,j)*x(j); % Mathematical definition of matvec prod.
    end % end for loop i
end % end for loop j

% Are the results same?
isSame = (b == b_t);
disp(isSame)

% While loops
% More general than for loops, as they can run indefinitely in contrast to for 
% loops which only run for a set number of values.

% Example Problem: Find the sqrt of 2 using Babylonian method
% https://en.wikipedia.org/wiki/Methods_of_computing_square_roots#Babylonian_method

disp(sqrt(2)) % Show the result from MATLAB's native function for comparison

x_0 = 1; % Initial guess
while (abs(x_0^2-2)>1e-6) % Run until error is less than 10^{-6}
    x_temp = 2/x_0; % If x_0 is the actual sqrt(2), then x_0 should be equal to
                    % 2/x_0.
    x_0 = (x_temp+x_0)/2; % Improve the guess by averaging x_0 and x_temp, as
                          % the average a better approximation then either of 
                          % x_0 and x_temp
end % end while loop
disp(x_0) % show the result

% We now implement this as a function in file mysqrt.m. There we introduce IF 
% statements for error checking (and also demonstrate the syntax for IF 
% statements)
mysqrt(10,2)

% Plotting
x = -2:0.1:2;
y = exp(x);
z = x;
plot(x,y,'r') % Plot f(x) = e^x with red line color
hold on       % We need this to prevent overwriting by the next plot
plot(x,z)     % Plot g(x) = x with default line color
legend('exp(x)','x') % Legend to distinguish between them
title('Plot of some functions') % Put a descriptive title to the graph
print -dpng fig1.png % Save plot to a png file. Especially useful if you are
                     % working on command line.

% We can also plot them side by side
figure % Create a new figure
subplot(2,1,1) % create a subfigure (2 rows, 1 column) and we are plotting the 
               % first entry.
plot(x,y,'r')  % Plot f(x) = e^x with red line color
subplot(2,1,2) % now we are plotting the second entry
plot(x,z)      % Plot g(x) = x with default line color

% We can also do higher dimensional plots
figure % Create a new figure
x=[0:2*pi/20:2*pi]; % x in interval (0,2*pi) with pi/10 steps
y=x;                % y in the same interval.
z=sin(x)'*cos(y);   % z = f(x,y) = sin(x)*cos(y)
surf(x,y,z)         % make a surface plot (3d plot)
xlabel('x')         % label the axes correctly for readability.
ylabel('y')
zlabel('result')
colormap('bone')    % change the color scheme to something you like
