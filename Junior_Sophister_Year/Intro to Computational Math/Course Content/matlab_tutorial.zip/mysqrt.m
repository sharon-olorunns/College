function out = mysqrt(x, guess)
% Computes the square root of given function using the Babylonian method.
% https://en.wikipedia.org/wiki/Methods_of_computing_square_roots#Babylonian_method
%
%  x is the number
%  guess is the initial guess for the sqrt
%  out is the approximation to the sqrt
if (x<0)
    error('Does not work for negative numbers.')
elseif (x==0) 
    out = 0; % sqrt(0) is 0, so we don't have to run the algorithm.
else
    while (abs(guess^2-x)>1e-6)
        x_temp = x/guess; % if guess = sqrt(x), then guess should be x/guess
        guess = (x_temp+guess)/2; % average of guess and x_temp is a better
                                  % approximation than either of them.
    end
    out = guess;    
end
