disp("Welcome to AMATH242/CS371 Tutorial")
disp("This is an example of a script")
disp("Result is 242.")