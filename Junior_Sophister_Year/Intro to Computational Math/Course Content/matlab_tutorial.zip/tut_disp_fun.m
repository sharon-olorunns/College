function out = tut_disp_fun(in)
  disp("Welcome to AMATH242/CS371 Tutorial")
  disp("This is an example of a function")
  disp(["Result is " + num2str(in) + "."])
  out = in;