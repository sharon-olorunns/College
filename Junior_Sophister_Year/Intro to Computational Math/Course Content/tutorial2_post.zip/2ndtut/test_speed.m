%% Comparing codes for speed.
% Run multiple times and take the smallest results.
x = rand(10000,1);
y = rand(10000,1);

tic
for i=1:10
    v = mydot(x,y);
end
toc

tic
for i=1:10
    v = dot(x,y);
end
toc
% Our mydot function is half as fast as MATLAB native function

A = rand(100,50);
B = rand(50,150);

tic
for i=1:10
    C = matmat(A,B);
end
toc

tic
for i=1:10
    C = A*B;
end
toc
% Our matmat function is four times slower than MATLAB native function
