function v = mydot(x,y)
% Given two vectors x,y of same size computes the inner product
%    v = \sum_i x_i*y_i
v = 0;
if (length(x)==length(y))
    for i = 1:length(x)
        v = v + x(i)*y(i);
    end
else
    error('Vectors should be of equal size.')
end