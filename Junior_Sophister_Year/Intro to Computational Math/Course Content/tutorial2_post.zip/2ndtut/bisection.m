function r = bisection(f, a, b)
% Given a function f:R->R with f(a)*f(b)<0, finds r such that f(r) is
% approximately zero.
it = 0;
if f(a)*f(b)>0 
    disp('f(a) and f(b) should have different signs.')
else
    r = (a + b)/2;
    err = abs(f(r));
    while (err > 1e-13 && it < 50)
       if f(a)*f(r)<0 
           b = r;
       else
           a = r;          
       end
       r = (a + b)/2; 
       err = abs(f(r));
       it = it + 1;
    end
end