function C = matmat(A,B)
% Given matrix A of size nxm and matrix B of size mxk computes
%    C = A*B
% Uses mydot function.
C = zeros(size(A,1),size(B,2));
for i = 1:size(A,1)
    for j = 1:size(B,2)
        C(i,j) = mydot(A(i,:),B(:,j));
    end
end
