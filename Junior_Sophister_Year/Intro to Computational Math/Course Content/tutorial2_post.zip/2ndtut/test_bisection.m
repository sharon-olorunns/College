%% Test script for bisection
% Alongside being a test script for bisection function, demonstrates the
% usage of inline functions and formatted output.

% f(x) = (x-1)(x-3)
f = @(x) (x-1).*(x-3);
fprintf('\n\tf(x) = (x-1).*(x-3)\n');
fprintf('The value of the function at point %g is %g.\n',0,f(0));
fprintf('The value of the function at point %g is %g.\n',2,f(2));
fprintf('The value of the function at point %g is %g.\n',1,f(1));
r = bisection(f,0,2);
fprintf('We found %g to be approximate root.\n',r);
fprintf('The value of the function at point %g is %g.\n',r,f(r));

% f(x) = cos(x)
f = @(x) cos(x);
fprintf('\n\tf(x) = cos(x)\n');
fprintf('The value of the function at point %g is %g.\n',0,f(0));
fprintf('The value of the function at point %g is %g.\n',pi,f(pi));
fprintf('The value of the function at point %g is %g.\n',pi/2,f(pi/2));
r = bisection(f,0,pi);
fprintf('We found %g to be approximate root.\n',r);
fprintf('The value of the function at point %g is %g.\n',r,f(r));

% f(x) = exp(x) - 3;
f = @(x) exp(x) - 3;
fprintf('\n\tf(x) = exp(x) - 3\n');
fprintf('The value of the function at point %g is %g.\n',-3,f(-3));
fprintf('The value of the function at point %g is %g.\n',3,f(3));
fprintf('The value of the function at point %g is %g.\n',0,f(0));
r = bisection(f,-3,3);
fprintf('We found %g to be approximate root.\n',r);
fprintf('The value of the function at point %g is %g.\n',r,f(r));