%% Test script for qroots
% Thorough testing is important to show that your algorithm is robust.

% p = 1 + 2x + x^2 = (x+1)^2, r1 = -1, r2 = -1
[r1,r2] = qroots(1,2,1);
disp([r1,r2])

% p = 2 - x + x^2 = (x+1)(x-2), r1 = -1, r2 = 2
[r1,r2] = qroots(1,-1,-2);
disp([r1,r2])

% p = 0 - 2x + x^2 = x(x-2), r1 = 0, r2 = 2
[r1,r2] = qroots(1,-2,0);
disp([r1,r2])

% p = 10^16 + 2*10^8x + x^2 = (x+10^8)^2
[r1,r2] = qroots(1,2e8,1e16);
disp([r1,r2])

% p = 10^16 - 2*10^8x + x^2 = (x-10^8)^2
[r1,r2] = qroots(1,-2e8,1e16);
disp([r1,r2])

% p = 1 + 10^8x + x^2
[r1,r2] = qroots(1,1e8,1);
disp([r1,r2]) % returns correct result now!