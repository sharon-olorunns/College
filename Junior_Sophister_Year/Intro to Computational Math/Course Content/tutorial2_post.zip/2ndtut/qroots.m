function [r1,r2] = qroots(a0,a1,a2)
% Given the coefficients of a quadratic polynomial
%    p = a2 + a1*x + a0*x2,
% returns the roots r1, r2 of the polynomial p.
%

% if a1>0 using quadratic formula might cause catastrophic cancellation. We
% check for it and use the appropriate formula.
if (a1>0)
    r1 = (-a1-sqrt(a1^2-4*a0*a2))/2/a0; % Using quadratic formula
    % Avoid dividing by zero
    if ~(r1==0)
        r2 = a2/a0/r1; % r2 = a2/(a0*r1)
    else
        r2 = (-a1+sqrt(a1^2-4*a0*a2))/2/a0; % Using quadratic formula
    end    
else
    r1 = (-a1+sqrt(a1^2-4*a0*a2))/2/a0; % Using quadratic formula
    % Avoid dividing by zero
    if ~(r1==0)
        r2 = a2/a0/r1; % r2 = a2/(a0*r1)
    else
        r2 = (-a1-sqrt(a1^2-4*a0*a2))/2/a0; % Using quadratic formula
    end
end