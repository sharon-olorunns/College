%% Native MATLAB functions
% You are expected to use native functions UNLESS you are ASKED TO
% IMPLEMENT it. Note that, creating a function and calling a native MATLAB
% function in it is NOT IMPLEMENTING it.

% Inner (dot) product of two vectors; v = x^T y
x = [1;1;1]; y=[1;2;3];
v = x'*y;
v = dot(x,y); % Same as above line but more general

% Matrix-Vector product
A = rand(5,5);
x = rand(5,1);
b = A*x;

% Matrix-matrix product
A = rand(5,4);
B = rand(4,5);
C = A*B;

% Outer product of two vector v = y x^T
x = [1;1;1]; y=[1;2;3];
v = y*x';
v = kron(y,x); % Same as above line but more general (Kronecker product)

% Finding the roots of polynomial
r = roots([1,2,10]);

% Creating a polynomial from given roots
p = poly(r);

% Finding the zero of nonlinear scalar function
f = @(x) sin(x);
x0 = 3;
zero = fzero(f,x0);